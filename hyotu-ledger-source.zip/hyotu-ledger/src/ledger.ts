export type CategoryType = 'income' | 'expense' | 'saving';
export type CarryMode = 'add' | 'target' | 'reset';
export type Category = { id: string; name: string; icon: string; color: string; type: CategoryType; archived: boolean; carry: CarryMode; template: number; parentId?: string };
export type Kind = 'income' | 'expense' | 'refund' | 'move' | 'opening';
export type Entry = { id: string; date: string; amount: number; kind: Kind; categoryId?: string; from?: string; to?: string; memo: string; originalId?: string; recurringKey?: string; tag?: string };
export type Repeat = { id: string; name: string; amount: number; categoryId: string; day: number; start: string; end?: string; active: boolean };
export type Ledger = { schema: 1; categories: Category[]; entries: Entry[]; repeats: Repeat[]; reviewedPeriods: string[] };
export const FREE = '_free';
export const uid = () => typeof crypto.randomUUID==='function'?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');
export const won = (n: number) => `${Math.round(n).toLocaleString('ko-KR')}원`;
export const compact = (n: number) => Math.abs(n) >= 10000 ? `${Number((n/10000).toFixed(1))}만` : n.toLocaleString('ko-KR');
export function today() { return new Intl.DateTimeFormat('sv-SE', {timeZone:'Asia/Seoul'}).format(new Date()); }
export function dateOf(y: number, m: number, d: number) { return `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`; }
export function parts(s: string) { return s.split('-').map(Number); }
export function addDays(s: string, n: number) { const [y,m,d]=parts(s); const t=new Date(Date.UTC(y,m-1,d+n)); return dateOf(t.getUTCFullYear(),t.getUTCMonth(),t.getUTCDate()); }
export function periodOf(s: string) { const [y,m,d]=parts(s); const t=new Date(Date.UTC(y,m-1-(d<20?1:0),20));return dateOf(t.getUTCFullYear(),t.getUTCMonth(),20); }
export function shiftPeriod(s: string, n: number) { const [y,m]=parts(s); const t=new Date(Date.UTC(y,m-1+n,20));return dateOf(t.getUTCFullYear(),t.getUTCMonth(),20); }
export function periodEnd(s: string) { return addDays(shiftPeriod(s,1),-1); }
export function periodDays(s: string) { const out:string[]=[]; for(let d=s;d<=periodEnd(s);d=addDays(d,1))out.push(d);return out; }
export function shortDate(s:string) { const [y,m,d]=parts(s); return `${y}.${String(m).padStart(2,'0')}.${String(d).padStart(2,'0')}`; }
export const inPeriod = (date:string, start:string) => date>=start && date<=periodEnd(start);
export function emptyLedger(): Ledger { return { schema:1, categories:[
  {id:'salary',name:'월급',icon:'💸',color:'#6383ef',type:'income',archived:false,carry:'add',template:0},
  {id:'extra',name:'추가 수입',icon:'✨',color:'#e8aa3d',type:'income',archived:false,carry:'add',template:0},
  {id:'living',name:'생활비',icon:'🛒',color:'#6879e8',type:'expense',archived:false,carry:'target',template:400000},
  {id:'cat',name:'고양이',icon:'🐈',color:'#df9c54',type:'expense',archived:false,carry:'add',template:200000},
  {id:'food',name:'식비',icon:'🍚',color:'#ec819c',type:'expense',archived:false,carry:'target',template:0},
  {id:'fun',name:'취미·여가',icon:'🎧',color:'#8f7bca',type:'expense',archived:false,carry:'reset',template:0},
  {id:'emergency',name:'비상금',icon:'🌱',color:'#45a390',type:'saving',archived:false,carry:'add',template:0},
  {id:'deposit',name:'적금',icon:'🏦',color:'#6383ef',type:'saving',archived:false,carry:'add',template:0}
], entries:[], repeats:[], reviewedPeriods:[] }; }
export const budgetId = (l:Ledger, id:string) => l.categories.find(c=>c.id===id)?.parentId || id;
export const isInCategory = (l:Ledger, id:string|undefined, categoryId:string) => !!id&&(id===categoryId||l.categories.some(c=>c.id===id&&c.parentId===categoryId));
export const categoryName = (l:Ledger,id?:string) => {const c=l.categories.find(c=>c.id===id);return c?(c.parentId?`${l.categories.find(p=>p.id===c.parentId)?.name} › ${c.name}`:c.name):'';};
export const categoryActive = (l:Ledger,c:Category) => !c.archived&&(!c.parentId||l.categories.some(p=>p.id===c.parentId&&!p.archived));
export function orderedCategories(l:Ledger) {return l.categories.filter(c=>!c.parentId).flatMap(c=>[c,...l.categories.filter(s=>s.parentId===c.id)]);}
export function balances(l: Ledger, through='9999-12-31') { const b:Record<string,number>={[FREE]:0}; for(const c of l.categories)b[c.id]=0;
 for(const e of l.entries){if(e.date>through)continue; const a=e.amount;
 if(e.kind==='income')b[FREE]+=a;
 if(e.kind==='opening')b[e.to||FREE]=(b[e.to||FREE]||0)+a;
 if(e.kind==='expense'){const id=budgetId(l,e.categoryId!);b[id]=(b[id]||0)-a;}
 if(e.kind==='refund'){const id=budgetId(l,e.categoryId!);b[id]=(b[id]||0)+a;}
 if(e.kind==='move'){b[e.from!]=(b[e.from!]||0)-a;b[e.to!]=(b[e.to!]||0)+a;}
 }return b; }
export function summary(l:Ledger, start:string) { const b=balances(l,periodEnd(start)); const prev=balances(l,addDays(start,-1)); const es=l.entries.filter(e=>inPeriod(e.date,start)); const income=es.filter(e=>e.kind==='income').reduce((s,e)=>s+e.amount,0); const spent=es.reduce((s,e)=>s+(e.kind==='expense'?e.amount:e.kind==='refund'?-e.amount:0),0); const total=Object.values(b).reduce((s,n)=>s+n,0);const saved=l.categories.filter(c=>c.type==='saving').reduce((s,c)=>s+b[c.id],0);
 return {b,prev,income,spent,total,saved,available:total-saved,free:b[FREE],entries:es}; }
export function categoryStats(l:Ledger,c:Category,start:string) { const s=summary(l,start); const spent=s.entries.filter(e=>isInCategory(l,e.categoryId,c.id)).reduce((n,e)=>n+(e.kind==='expense'?e.amount:e.kind==='refund'?-e.amount:0),0);const bucket=c.parentId||c.id; const moves=s.entries.filter(e=>e.kind==='move').reduce((n,e)=>n+(e.to===bucket?e.amount:0)-(e.from===bucket?e.amount:0),0); const opening=s.entries.filter(e=>e.kind==='opening'&&e.to===bucket).reduce((n,e)=>n+e.amount,0);const budget=s.prev[bucket]+moves+opening;
 return {spent,budget,left:s.b[bucket],ratio:budget>0?Math.max(0,spent/budget):spent>0?1:0}; }
export function validateEntry(l:Ledger,e:Entry,editing=false,skipCrossChecks=false) { if(!Number.isSafeInteger(e.amount)||e.amount<=0||e.amount>1e12)throw Error('금액은 1원 이상 정수로 입력해 주세요.'); if(!validDate(e.date))throw Error('날짜를 확인해 주세요.'); if(e.memo.length>1000)throw Error('메모는 1,000자 이내로 입력해 주세요.');
 const cats=new Map(l.categories.map(c=>[c.id,c])); const bucket=(id?:string)=>id===FREE||!!id&&cats.has(id)&&cats.get(id)!.type!=='income'&&!cats.get(id)!.parentId;
 if(e.kind==='income'&&cats.get(e.categoryId||'')?.type!=='income')throw Error('수입 카테고리를 선택해 주세요.');
 if(['expense','refund'].includes(e.kind)&&cats.get(e.categoryId||'')?.type!=='expense')throw Error('지출 카테고리를 선택해 주세요.');
 if(e.kind==='opening'&&!bucket(e.to))throw Error('시작 잔액의 항목을 확인해 주세요.');
 if(e.kind==='move'&&(!bucket(e.from)||!bucket(e.to)||e.from===e.to))throw Error('서로 다른 출발·도착 항목을 선택해 주세요.');
 if(skipCrossChecks)return;
 const others=l.entries.filter(x=>x.id!==e.id);const base={...l,entries:others};
 if(e.kind==='move'&&!editing&&(balances(base,e.date)[e.from!]||0)-Math.min(0,l.entries.some(x=>x.id===e.id)?(balances(l,e.date)[e.from!]||0):0)<e.amount)throw Error('출발 항목의 잔액보다 많이 옮길 수 없어요. 먼저 수입이나 예산을 확인해 주세요.');
 if(e.kind==='refund'){const orig=others.find(x=>x.id===e.originalId&&x.kind==='expense');if(!orig||orig.categoryId!==e.categoryId)throw Error('환불할 원래 지출을 선택해 주세요.');if(e.date<orig.date)throw Error('환불일은 원래 지출일 이후여야 해요.');const already=others.filter(x=>x.originalId===orig.id&&x.kind==='refund').reduce((n,x)=>n+x.amount,0);if(already+e.amount>orig.amount)throw Error('원래 지출의 미환불 금액을 초과했어요.');}
 if(e.kind==='expense'){const refunds=others.filter(x=>x.originalId===e.id&&x.kind==='refund');if(refunds.some(x=>x.categoryId!==e.categoryId||x.date<e.date)||refunds.reduce((n,x)=>n+x.amount,0)>e.amount)throw Error('연결된 환불을 먼저 수정해 주세요.');}
 }
export function putEntry(l:Ledger,e:Entry):Ledger { validateEntry(l,e); return {...l,entries:[...l.entries.filter(x=>x.id!==e.id),e]}; }
export function removeEntry(l:Ledger,id:string):Ledger { if(l.entries.some(e=>e.originalId===id))throw Error('이 지출에 연결된 환불을 먼저 삭제해 주세요.');return {...l,entries:l.entries.filter(e=>e.id!==id)}; }
export type PlanMove={from:string;to:string;amount:number};
export function applyPlan(l:Ledger,start:string,moves:PlanMove[],allocations:Record<string,number>):Ledger { if(l.reviewedPeriods.includes(start))throw Error('이미 이월·배분을 확정한 기간이에요. 추가 조정은 예산 이동을 이용해 주세요.'); if(l.categories.some(c=>c.parentId&&(allocations[c.id]||0)!==0))throw Error('하위 항목은 상위 카테고리에 예산을 배분해 주세요.'); let next={...l,entries:[...l.entries]}; const prior=balances(l,addDays(start,-1));const bySource:Record<string,number>={};for(const m of moves){if(m.amount===0)continue;bySource[m.from]=(bySource[m.from]||0)+m.amount; if(bySource[m.from]>(prior[m.from]||0))throw Error('이월할 금액이 이전 기간 잔액을 초과했어요.');}
 // First release outgoing rollover amounts, then apply their destinations. No new income is created.
 const generated:Entry[]=moves.filter(m=>m.amount>0&&m.from!==m.to).map(m=>({id:uid(),kind:'move',date:start,amount:m.amount,from:m.from,to:m.to,memo:'기간 이월',tag:'rollover'}));
 for(const e of generated)validateEntry({...next,entries:[]},e,true);
 next.entries.push(...generated);
 for(const c of l.categories.filter(c=>c.type!=='income'&&!c.archived&&!c.parentId)){const amount=allocations[c.id]||0;if(amount===0)continue;const e:Entry={id:uid(),kind:'move',date:start,amount,from:FREE,to:c.id,memo:'기본 배분표 적용',tag:'allocation'};next=putEntry(next,e);}
 return {...next,reviewedPeriods:[...l.reviewedPeriods,start]}; }
export function suggestedAllocations(l:Ledger,start:string,moves:PlanMove[]) { const before={...l,entries:[...l.entries,...moves.filter(m=>m.amount>0&&m.from!==m.to).map(m=>({id:uid(),kind:'move' as const,date:start,amount:m.amount,from:m.from,to:m.to,memo:''}))]};const b=Object.fromEntries(l.categories.map(c=>[c.id,categoryStats(before,c,start).budget]));return Object.fromEntries(l.categories.filter(c=>!c.archived&&c.type!=='income'&&!c.parentId).map(c=>[c.id,c.carry==='target'?Math.max(0,c.template-(b[c.id]||0)):c.template])); }
export function dueRepeats(l:Ledger,start:string) { const out:{repeat:Repeat;date:string;key:string}[]=[];for(const date of periodDays(start)){const [y,m,d]=parts(date);const last=new Date(Date.UTC(y,m,0)).getUTCDate();for(const r of l.repeats){const key=`${r.id}:${date}`;if(r.active&&date>=r.start&&(!r.end||date<=r.end)&&d===Math.min(r.day,last)&&!l.entries.some(e=>e.recurringKey===key))out.push({repeat:r,date,key});}}return out; }
export function validDate(s:unknown):s is string { if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const [y,m,d]=parts(s);if(y<1900||y>2200)return false;const dt=new Date(Date.UTC(y,m-1,d));return dateOf(dt.getUTCFullYear(),dt.getUTCMonth(),dt.getUTCDate())===s; }
export function validateLedger(raw:unknown):Ledger { const l=raw as Ledger;if(!l||l.schema!==1||!Array.isArray(l.categories)||!Array.isArray(l.entries)||!Array.isArray(l.repeats)||!Array.isArray(l.reviewedPeriods))throw Error('지원하는 가계부 백업 파일이 아니에요.');if(l.categories.length>300||l.entries.length>100000||l.repeats.length>500)throw Error('백업 파일의 크기가 너무 커요.');const ids=new Set<string>();for(const c of l.categories){if(typeof c.id!=='string'||!c.id||['__proto__','constructor','prototype',FREE].includes(c.id)||ids.has(c.id)||typeof c.name!=='string'||!c.name.trim()||c.name.length>40||typeof c.icon!=='string'||c.icon.length>30||!/^#[0-9a-fA-F]{6}$/.test(c.color)||!['income','expense','saving'].includes(c.type)||!['add','target','reset'].includes(c.carry)||typeof c.archived!=='boolean'||!Number.isSafeInteger(c.template)||c.template<0||c.template>1e12)throw Error('카테고리 형식이 잘못되었어요.');ids.add(c.id);}
 for(const c of l.categories){if(c.parentId!==undefined){const parent=l.categories.find(p=>p.id===c.parentId);if(typeof c.parentId!=='string'||c.type!=='expense'||!parent||parent.type!=='expense'||parent.parentId||parent.id===c.id||c.template!==0)throw Error('하위 항목은 상위 지출 카테고리의 예산을 함께 사용해야 해요.');}}
 const eids=new Set<string>();for(const e of l.entries){if(!e||typeof e.id!=='string'||eids.has(e.id)||!['income','expense','refund','move','opening'].includes(e.kind)||typeof e.memo!=='string')throw Error('기록 형식이 잘못되었어요.');eids.add(e.id);validateEntry(l,e,true,true);}
 const originals=new Map(l.entries.filter(e=>e.kind==='expense').map(e=>[e.id,e]));const refunded=new Map<string,number>();for(const e of l.entries.filter(e=>e.kind==='refund')){const original=originals.get(e.originalId||'');if(!original||original.categoryId!==e.categoryId||e.date<original.date)throw Error('환불 기록의 연결이 잘못되었어요.');const amount=(refunded.get(original.id)||0)+e.amount;if(amount>original.amount)throw Error('환불 합계가 원래 지출보다 커요.');refunded.set(original.id,amount);}
 for(const r of l.repeats){if(typeof r.id!=='string'||typeof r.name!=='string'||r.name.length>100||!Number.isSafeInteger(r.amount)||r.amount<1||r.amount>1e12||!Number.isInteger(r.day)||r.day<1||r.day>31||typeof r.active!=='boolean'||!validDate(r.start)||(r.end&&!validDate(r.end))||!l.categories.some(c=>c.id===r.categoryId&&c.type==='expense'))throw Error('반복 내역 형식을 확인해 주세요.');}
 if(l.reviewedPeriods.some(p=>!validDate(p)||periodOf(p)!==p))throw Error('기간 형식이 잘못되었어요.');return structuredClone(l); }
export function demoLedger():Ledger {const l=emptyLedger();const p=periodOf(today()); const d=(n:number)=>addDays(p,n);const es:Entry[]=[
{id:uid(),kind:'income',date:p,amount:1600000,categoryId:'salary',memo:'이번 달 월급'},
{id:uid(),kind:'move',date:p,amount:400000,from:FREE,to:'living',memo:'생활비 배분'},
{id:uid(),kind:'move',date:p,amount:200000,from:FREE,to:'cat',memo:'고양이 예산'},
{id:uid(),kind:'move',date:p,amount:250000,from:FREE,to:'food',memo:'식비 배분'},
{id:uid(),kind:'move',date:p,amount:100000,from:FREE,to:'fun',memo:'취미 예산'},
{id:uid(),kind:'move',date:p,amount:300000,from:FREE,to:'deposit',memo:'차곡차곡 적금'},
{id:uid(),kind:'expense',date:p,amount:23500,categoryId:'living',memo:'생활용품 장보기'},
{id:uid(),kind:'expense',date:d(1),amount:48500,categoryId:'cat',memo:'고양이 사료와 간식'},
{id:uid(),kind:'expense',date:d(1),amount:12000,categoryId:'food',memo:'든든한 점심'},
{id:uid(),kind:'expense',date:d(2),amount:6500,categoryId:'food',memo:'퇴근길 커피'},
{id:uid(),kind:'expense',date:d(3),amount:18000,categoryId:'fun',memo:'좋아하는 영화 한 편'}];return {...l,entries:es,repeats:[{id:uid(),name:'음악 구독',amount:10900,categoryId:'fun',day:25,start:p,active:true}]}; }
